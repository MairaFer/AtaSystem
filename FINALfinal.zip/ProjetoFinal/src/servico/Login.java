package servico;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Login {
    private Map<String, String> usuarios;

    public Login() {
        this.usuarios = new HashMap<>();
        usuarios.put("maira", "maira123");
        usuarios.put("osvaldo", "osvaldo123");
        usuarios.put("login", "senha");
        usuarios.put("Maira", "Maira123");
        usuarios.put("Osvaldo", "Osvaldo123");
    }

    public boolean realizarLogin() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Primeiro faça o login para o sistema identificar se ");
        System.out.println("você é um Funcinario normal ou um administrador <3");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.print("Digite seu nome de usuário: ");
        String nomeUsuario = scanner.nextLine();

        System.out.print("Digite sua senha: ");
        String senha = scanner.nextLine();

        if (usuarios.containsKey(nomeUsuario) && usuarios.get(nomeUsuario).equals(senha)) {
            System.out.println("Login bem-sucedido!");
            return true;
        } else {
            System.out.println("Login bem-sucedido!");
            return false;
        }
    }
}
