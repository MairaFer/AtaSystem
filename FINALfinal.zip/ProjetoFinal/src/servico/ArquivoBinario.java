package servico;

import modelo.Ata;

import java.io.*;
import java.util.List;

public class ArquivoBinario {

    public void salvarEmArquivo(List<Ata> atas, String caminho) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(caminho))) {
            oos.writeObject(atas);
            System.out.println("lista de atas salva com sucesso em: " + caminho);
        } catch (IOException e) {
            System.err.println("Erro ao salvar ata em arquivo binário: " + e.getMessage());
        }
    }

    public List<Ata> carregarDeArquivo(String caminho) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(caminho))) {
            List<Ata> atas = (List<Ata>) ois.readObject();
            System.out.println("Lista de Atas carregada com sucesso de: " + caminho);
            return atas;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erro ao carregar lista de Atas de arquivo binário: " + e.getMessage());
            return null;
        }
    }
}
