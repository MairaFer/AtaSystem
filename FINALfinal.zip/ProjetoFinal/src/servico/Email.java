package servico;

import modelo.Ata;
import java.util.Date;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;


public class Email {
	public void notificarRevisaoAta(Ata ata) {
	    if (ata != null) {
	        System.out.println("Enviando e-mail de notificação para revisão da ata: " + ata.getTitulo());
	        criarArquivoNotificacao(ata);
	    } else {
	        System.out.println("Atenção: O objeto Ata fornecido é nulo.");
	    }
	}

	private void criarArquivoNotificacao(Ata ata) {
		String nomeArquivo = "notificacao_" + ata.getTitulo() + ".txt";

		 try (PrintWriter writer = new PrintWriter(new FileWriter(nomeArquivo))) {
	            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	            writer.println("Notificação de Revisão da Ata");
	            writer.println("=============================");
	            writer.println("Ata: " + ata.getTitulo());
	            writer.println("Data de Emissão: " + dateFormat.format(ata.getDataEmissao()));
	            writer.println("Emissor: " + ata.getEmissor().getNome()); 
	            writer.println("Setor: " + ata.getSetor().getNome());
	            writer.println("Pauta: " + ata.getPauta());
	            writer.println("Descrição: " + ata.getDescricao());
	            writer.println("Estado: " + ata.getEstado());
	            writer.println("Visibilidade: " + ata.getVisibilidade());
	            writer.println("Hora de Início: " + dateFormat.format(ata.getHoraInicio()));
	            writer.println("Hora de Fim: " + dateFormat.format(ata.getHoraFim()));
		} catch (IOException e) {
			System.err.println("Erro ao criar arquivo de notificação: " + e.getMessage());
		}
	}

}
