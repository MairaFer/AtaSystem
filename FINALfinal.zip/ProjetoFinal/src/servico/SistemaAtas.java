package servico;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import modelo.*;
import utilitario.Relatorio;

public class SistemaAtas {

	private List<Ata> atas;
	private ArquivoBinario arquivoBinario;
	private Relatorio relatorio;

	private static final String BIN_FILE_PATH = "atas.bin";

	public SistemaAtas(List<Ata> atas, ArquivoBinario arquivoBinario) {
		this.atas = atas;
		this.arquivoBinario = arquivoBinario;
		this.relatorio = new Relatorio();
	}

	public List<Ata> getAtas() {
		return atas;
	}

	public void setAtas(List<Ata> atas) {
		this.atas = atas;
	}

	public ArquivoBinario getArquivoBinario() {
		return arquivoBinario;
	}

	public void setArquivoBinario(ArquivoBinario arquivoBinario) {
		this.arquivoBinario = arquivoBinario;
	}

	public static void salvarAtas(Map<Date, Ata> atas, String nomeArquivo) {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nomeArquivo))) {
			oos.writeObject(atas);
			System.out.println("Atas salvas com sucesso!");
		} catch (IOException e) {
			System.err.println("Erro ao salvar atas: " + e.getMessage());
		}
	}

	public void criarNovaAta(Scanner scanner) {
		System.out.println("~~~~~~Criar Nova Ata~~~~~~");

		System.out.print("Nome do emissor: ");
		String nomeEmissor = scanner.nextLine();

		System.out.print("E-mail do emissor: ");
		String emailEmissor = scanner.nextLine();

		System.out.print("Cargo do emissor: ");
		String cargoEmissor = scanner.nextLine();

		Funcionario emissor = new Funcionario(nomeEmissor, emailEmissor, cargoEmissor);

		System.out.print("Título da ata: ");
		String titulo = scanner.nextLine();

		System.out.print("Data de emissão (no formato dd/MM/yyyy): ");
		String dataEmissaoStr = scanner.nextLine();
		Date dataEmissao = null;
		try {
			dataEmissao = new SimpleDateFormat("dd/MM/yyyy").parse(dataEmissaoStr);
		} catch (ParseException e) {
			System.out.println("Formato de data inválido.");
			dataEmissao = new Date();
		}
		System.out.print("Qual o setor da reunião? (Opções: 'adm', 'ti', 'rh'): ");
		String setorAta = scanner.nextLine();

		if (!setorAta.equalsIgnoreCase("adm") && !setorAta.equalsIgnoreCase("ti") && !setorAta.equalsIgnoreCase("rh")) {
			System.out.println("Setor inválido. Escolha entre 'adm', 'ti' e 'rh'.");
			return;
		}

		Setor setor = new Setor(setorAta);

		System.out.print("Qual a pauta da reunião?: ");
		String pauta = scanner.nextLine();

		System.out.print("Forneca uma descrição: ");
		String descricao = scanner.nextLine();

		System.out.println("~Palavras-Chave~");
		System.out.print("Quantidade de palavras-chave: ");
		int numeroPalavrasChave = scanner.nextInt();
		scanner.nextLine();

		List<String> palavrasChave = new ArrayList<>();

		for (int j = 0; j < numeroPalavrasChave; j++) {
			System.out.print("Palavra-chave " + (j + 1) + ": ");
			String palavraChave = scanner.nextLine();
			palavrasChave.add(palavraChave);
		}

		System.out.print("Deseja tornar essa reunião privada? (Digite 'sim' para sim): ");
		String respostaVisibilidade = scanner.nextLine();
		String visibilidade = "publica";

		if ("sim".equalsIgnoreCase(respostaVisibilidade)) {
			visibilidade = "privada";
		}

		SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm");

		System.out.print("Hora de Início da Reunião (HH:mm): ");
		String horaInicioStr = scanner.nextLine();

		System.out.print("Hora de Término da Reunião (HH:mm): ");
		String horaFimStr = scanner.nextLine();

		Date horaInicio = null;
		Date horaFim = null;

		try {
			horaInicio = formatoHora.parse(horaInicioStr);
			horaFim = formatoHora.parse(horaFimStr);
		} catch (ParseException e) {
			System.out.println("Formato de hora inválido.");
			return;
		}

		List<Participante> participantes = new ArrayList<>();
		System.out.print("Número de participantes: ");
		int numeroParticipantes = scanner.nextInt();
		scanner.nextLine();

		for (int i = 0; i < numeroParticipantes; i++) {
			System.out.println("~~~~~~Informações do Participante " + (i + 1) + "~~~~~~");
			System.out.print("Nome do participante " + (i + 1) + ": ");
			String nomeParticipante = scanner.nextLine();

			System.out.print("E-mail do participante: ");
			String emailParticipante = scanner.nextLine();

			System.out.print("O participante é um funcionário (F) ou um participante externo (E)? ");
			char tipoParticipante = scanner.nextLine().toUpperCase().charAt(0);
			System.out.println(" ");
			if (tipoParticipante == 'F') {
				System.out.print("Cargo do funcionário: ");
				String cargoFuncionario = scanner.nextLine();

				participantes.add(new Funcionario(nomeParticipante, emailParticipante, cargoFuncionario));
			} else if (tipoParticipante == 'E') {
				System.out.print("Empresa do participante externo: ");
				String empresaParticipanteExterno = scanner.nextLine();

				participantes
						.add(new ParticipanteExterno(nomeParticipante, emailParticipante, empresaParticipanteExterno));
			} else {
				System.out.println(
						"Tipo de participante inválido. Por favor, escolha 'F' para funcionário ou 'E' para participante externo.");
				i--;
			}
		}

		System.out.print("Deseja enviar essa ata para o processo de revisão? (Digite 'sim' para sim): ");
		String respostaEstado = scanner.nextLine();
		String estado = "pré-emitida";
		System.out.println(" ");

		Ata novaAta = new Ata(titulo, dataEmissao, emissor, participantes, setor, pauta, descricao, palavrasChave,
				estado, visibilidade, horaInicio, horaFim);

		if ("sim".equalsIgnoreCase(respostaEstado)) {
			estado = "em processo de revisão";

			Email email = new Email();
			email.notificarRevisaoAta(novaAta);
			System.out.print("Deseja confirmar a mudança do estado para 'emitida'? (Digite 'sim' para sim): ");
			String confirmacaoEstado = scanner.nextLine();
			System.out.println(" ");
			if ("sim".equalsIgnoreCase(confirmacaoEstado)) {
				estado = "emitida";
			}
		}

		salvarAtaEmArquivo(novaAta);
		System.out.println("Nova ata criada com sucesso!");
		System.out.println(" ");
	}

	private void salvarAtaEmArquivo(Ata ata) {
		List<Ata> atas = listarAtas();
		atas.add(ata);
		setAtas(atas);

		salvarAtasEmArquivo(atas);
	}

	private void salvarAtasEmArquivo(List<Ata> atas) {
		ArquivoBinario arquivoBinario = new ArquivoBinario();
		arquivoBinario.salvarEmArquivo(atas, BIN_FILE_PATH);
	}

	public Ata criarAta(String titulo, Date dataEmissao, Funcionario emissor, List<Participante> participantes,
			Setor setor, String pauta, String descricao, List<String> palavrasChave, String estado, String visibilidade,
			Date horaInicio, Date horaFim) {
		if (ataComTituloExiste(titulo)) {
			System.out.println("Já existe uma ata com o mesmo título. Não é possível criar duplicatas.");
			return null;
		}

		if (!participantes.contains(emissor)) {
			System.out.println("O emissor deve ser um participante da reunião.");
			return null;
		}

		if (participantes.size() < 2) {
			System.out.println("Uma reunião deve ter pelo menos dois participantes.");
			return null;
		}
		Ata novaAta = new Ata(titulo, dataEmissao, emissor, participantes, setor, pauta, descricao, palavrasChave,
				estado, visibilidade, horaInicio, horaFim);

		adicionarAta(novaAta);

		System.out.println("Ata criada com sucesso!");
		return novaAta;
	}

	private boolean ataComTituloExiste(String titulo) {
		for (Ata ata : atas) {
			if (ata.getTitulo().equals(titulo)) {
				return true;
			}
		}
		return false;
	}

	private void adicionarAta(Ata novaAta) {
		atas.add(novaAta);
	}

	public void consultarAtas(Scanner scanner) {
		List<Ata> atas = carregarAtasDoArquivo();

		if (atas.isEmpty()) {
			System.out.println("Não há atas disponíveis para consulta.");
			return;
		}

		System.out.println("~~~~~~~~~~ATAS PÚBLICAS~~~~~~~:");
		int count = 1;
		for (Ata ata : atas) {
			if ("publica".equalsIgnoreCase(ata.getVisibilidade())) {
				System.out.println(count + ". " + ata.getTitulo() + " - " + ata.getDataEmissao());
				count++;
			}
		}

		if (count == 1) {
			System.out.println("Não há atas públicas disponíveis para consulta.");
			return;
		}

		System.out.print("Digite o número da ata para visualizar detalhes (ou 0 para voltar): ");

		int escolha;
		try {
			escolha = scanner.nextInt();
			scanner.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("Opção inválida. Digite um número válido.");
			scanner.nextLine();
			return;
		}

		if (escolha == 0) {
			System.out.println("Retornando ao menu principal.");
			return;
		}

		if (escolha < 1 || escolha >= count) {
			System.out.println("Opção inválida. Tente novamente.");
			return;
		}

		Ata ataEscolhida = buscarAtaPublica(atas, escolha);
		exibirDetalhesAta(ataEscolhida);
	}

	private List<Ata> carregarAtasDoArquivo() {
		ArquivoBinario arquivoBinario = new ArquivoBinario();
		List<Ata> atas = (List<Ata>) arquivoBinario.carregarDeArquivo(BIN_FILE_PATH);
		if (atas == null) {
			System.out.println("Não foi possível carregar as atas do arquivo binário. Criando nova lista.");
			atas = new ArrayList<>();
		}
		return atas;
	}

	private Ata buscarAtaPublica(List<Ata> atas, int escolha) {
		int count = 1;
		for (Ata ata : atas) {
			if ("publica".equalsIgnoreCase(ata.getVisibilidade())) {
				if (count == escolha) {
					return ata;
				}
				count++;
			}
		}
		return null;
	}

	private void exibirDetalhesAta(Ata ata) {
		if (ata != null) {
			System.out.println("Detalhes da Ata:");
			System.out.println("Título: " + ata.getTitulo());
			System.out.println("Data de Emissão: " + ata.getDataEmissao());
			System.out.println("Emissor: " + ata.getEmissor().getNome() + " (" + ata.getEmissor().getEmail() + ")");
			System.out.println("Setor: " + ata.getSetor().getNome());
			System.out.println("Pauta: " + ata.getPauta());
			System.out.println("Descrição: " + ata.getDescricao());
			System.out.println("Palavras-Chave: " + String.join(", ", ata.getPalavrasChave()));
			System.out.println("Visibilidade: " + ata.getVisibilidade());
			System.out.println("Hora de Início: " + new SimpleDateFormat("HH:mm").format(ata.getHoraInicio()));
			System.out.println("Hora de Término: " + new SimpleDateFormat("HH:mm").format(ata.getHoraFim()));

			System.out.println("Participantes:");
			for (Participante participante : ata.getParticipantes()) {
				if (participante instanceof Funcionario) {
					Funcionario funcionario = (Funcionario) participante;
					System.out
							.println(" - Funcionário: " + funcionario.getNome() + " (" + funcionario.getEmail() + ")");
					System.out.println("   Cargo: " + funcionario.getCargo());
				} else if (participante instanceof ParticipanteExterno) {
					ParticipanteExterno externo = (ParticipanteExterno) participante;
					System.out
							.println(" - Participante Externo: " + externo.getNome() + " (" + externo.getEmail() + ")");
					System.out.println("   Empresa: " + externo.getEmpresa());
				}
			}

			System.out.println("Estado da Ata: " + ata.getEstado());
		}
	}

	public void emitirAta(Ata ata) {
		if ("pré-emitida".equals(ata.getEstado())) {
			ata.setEstado("emitida");
			System.out.println("Ata emitida com sucesso!");
		} else {
			System.out.println("A ata não pode ser emitida. O estado atual é: " + ata.getEstado());
		}
	}

	public void realizarSugestaoAlteracao(Scanner scanner) {
		System.out.println("~~~~~~Realizar Sugestão de Alteração~~~~~~");

		List<Ata> atas = carregarAtasDoArquivo();

		List<Ata> atasEmRevisao = new ArrayList<>();
		for (Ata ata : atas) {
			if ("em processo de revisão".equalsIgnoreCase(ata.getEstado())) {
				atasEmRevisao.add(ata);
			}
		}

		if (atasEmRevisao.isEmpty()) {
			System.out.println("Não há atas disponíveis para sugestão de alteração.");
			return;
		}
		System.out.println("Lista de Atas Disponíveis:");
		for (int i = 0; i < atasEmRevisao.size(); i++) {
			Ata ata = atasEmRevisao.get(i);
			System.out.println((i + 1) + ". " + ata.getTitulo() + " - " + ata.getDataEmissao());
		}

		System.out.print("Escolha o número correspondente à ata desejada: ");
		int escolhaAta = scanner.nextInt();
		scanner.nextLine();

		if (escolhaAta < 1 || escolhaAta > atasEmRevisao.size()) {
			System.out.println("Opção inválida.");
			return;
		}

		Ata ataSelecionada = atasEmRevisao.get(escolhaAta - 1);

		System.out.print("Digite seu nome para verificar se você é um participante da ata: ");
		String nomeParticipante = scanner.nextLine();
		System.out.print("Agora digite o seu Email: ");
		String emailParticipante = scanner.nextLine();


		boolean isParticipante = false;
		for (Participante participante : ataSelecionada.getParticipantes()) {
			if (participante.getNome().equalsIgnoreCase(nomeParticipante)) {
				isParticipante = true;
				break;
			}
		}

		if (!isParticipante) {
			System.out.println("Você não é um participante desta ata. A sugestão de alteração não é permitida.");
			return;
		}

		iniciarRevisao(ataSelecionada);

		System.out.print("Digite a descrição da sugestão de alteração: ");
		String descricaoSugestao = scanner.nextLine();
		adicionarSugestao(nomeParticipante, emailParticipante, ataSelecionada, descricaoSugestao);

		concluirRevisao(ataSelecionada);
		System.out.println("Sugestão de alteração realizada com sucesso!");
	}

	public void adicionarSugestao(String nomeParticipante, String emailParticipante, Ata ataSelecionada,
			String descricaoSugestao) {
		Participante participante = new Participante(nomeParticipante, emailParticipante);
		participante.SugerirAlteracao(ataSelecionada, descricaoSugestao);
	}

	public void iniciarRevisao(Ata ata) {
		if ("pré-emitida".equals(ata.getEstado()) || "em processo de revisão".equals(ata.getEstado())) {
			ata.setEstado("em processo de revisão");
			System.out.println("Revisão da ata iniciada com sucesso!");
		} else {
			System.out.println("A revisão da ata não pode ser iniciada. O estado atual é: " + ata.getEstado());
		}
	}

	public void concluirRevisao(Ata ata) {
		if ("em processo de revisão".equals(ata.getEstado())) {
			ata.setEstado("emitida");
			System.out.println("Revisão da ata concluída com sucesso!");
		} else {
			System.out.println("A revisão da ata não pode ser concluída. O estado atual é: " + ata.getEstado());
		}
	}

	public void mudarEstadoAta(Scanner scanner) {
		System.out.println("~~~~~~Mudar Estado da Ata~~~~~~");

		List<Ata> atas = carregarAtasDoArquivo();

		List<Ata> atasParaAlterar = new ArrayList<>();
		for (Ata ata : atas) {
			if ("pré-emitida".equalsIgnoreCase(ata.getEstado())
					|| "em processo de revisão".equalsIgnoreCase(ata.getEstado())) {
				atasParaAlterar.add(ata);
			}
		}

		if (atasParaAlterar.isEmpty()) {
			System.out.println("Não há atas pré-emissão ou em processo de revisão disponíveis para alteração.");
			return;
		}

		System.out.println("Lista de Atas Disponíveis para Alteração:");
		for (int i = 0; i < atasParaAlterar.size(); i++) {
			Ata ata = atasParaAlterar.get(i);
			System.out.println((i + 1) + ". " + ata.getTitulo() + " - " + ata.getDataEmissao());
		}

		System.out.print("Escolha o número correspondente à ata desejada: ");
		int escolhaAta = scanner.nextInt();
		scanner.nextLine();

		if (escolhaAta < 1 || escolhaAta > atasParaAlterar.size()) {
			System.out.println("Opção inválida.");
			return;
		}

		Ata ataSelecionada = atasParaAlterar.get(escolhaAta - 1);

		System.out.print("Digite seu nome para verificar se você é o emissor da ata: ");
		String nomeEmissor = scanner.nextLine();

		if (!ataSelecionada.getEmissor().getNome().equalsIgnoreCase(nomeEmissor)) {
			System.out.println("Você não é o emissor desta ata. A alteração de estado não é permitida.");
			return;
		}

		System.out.print("Digite o novo estado para a ata (ex: 'emitida', 'em processo de revisão'): ");
		String novoEstado = scanner.nextLine();

		if ("em processo de revisão".equalsIgnoreCase(novoEstado)) {
			iniciarRevisao(ataSelecionada);
			concluirRevisao(ataSelecionada);

			Email email = new Email();
			email.notificarRevisaoAta(ataSelecionada);
		} else if ("emitida".equalsIgnoreCase(novoEstado)) {
			mudarEstado(ataSelecionada, novoEstado);
		} else {
			System.out.println("Opção de estado inválida.");
			return;
		}

		System.out.println("Estado da ata alterado com sucesso!");
	}

	public void mudarEstado(Ata ata, String novoEstado) {
		ata.setEstado(novoEstado);
		System.out.println("Estado da ata alterado para: " + novoEstado);
	}

	public List<Ata> listarAtas() {
		return atas;
	}

	public void excluirAtaSelecionada(Scanner scanner) {
		System.out.println("~~~~~~Excluir Ata~~~~~~");

		List<Ata> atas = listarAtas();

		if (atas.isEmpty()) {
			System.out.println("Não há atas disponíveis para excluir.");
			return;
		}

		System.out.println("Lista de Atas Disponíveis para Excluir:");
		for (int i = 0; i < atas.size(); i++) {
			Ata ata = atas.get(i);
			System.out.println((i + 1) + ". " + ata.getTitulo() + " - " + ata.getDataEmissao());
		}

		System.out.print("Escolha o número correspondente à ata que deseja excluir (ou 0 para voltar): ");
		int escolhaAta = scanner.nextInt();
		scanner.nextLine();

		if (escolhaAta == 0) {
			System.out.println("Operação de exclusão cancelada. Retornando ao menu principal.");
			return;
		}

		if (escolhaAta < 1 || escolhaAta > atas.size()) {
			System.out.println("Opção inválida.");
			return;
		}

		Ata ataSelecionada = atas.get(escolhaAta - 1);

		System.out.print("Digite seu nome para verificar se você é o emissor da ata: ");
		String nomeEmissor = scanner.nextLine();

		if (!ataSelecionada.getEmissor().getNome().equalsIgnoreCase(nomeEmissor)) {
			System.out.println("Você não é o emissor desta ata. A exclusão não é permitida.");
			return;
		}

		excluirAta(ataSelecionada);
		System.out.println("Ata excluída com sucesso!");
	}

	public void excluirAta(Ata ataSelecionada) {
		if (atas.contains(ataSelecionada)) {
			atas.remove(ataSelecionada);
			System.out.println("Ata excluída com sucesso!");
		} else {
			System.out.println("Ata não encontrada. Não foi possível excluir.");
		}
	}

	public void gerarRelatorioSetor() {
		System.out.println("~~~~~~Gerar Relatório por Setor~~~~~~");
		relatorio.gerarRelatorioSetor(getAtas());
	}

	public void gerarRelatorioFuncionario() {
		System.out.println("~~~~~~Gerar Relatório por Funcionário~~~~~~");
		relatorio.gerarRelatorioFuncionario(getAtas());
	}

	public void gerarRelatorioDuracaoReunioes() {
		System.out.println("~~~~~~Gerar Relatório de Duração das Reuniões~~~~~~");
		relatorio.gerarRelatorioDuracaoReunioes(getAtas());
	}

	public void consultarAtasEscolhidaPorPeriodo(Scanner scanner) {
		System.out.println("----- Consultar Atas por Período -----");

		System.out.print("Digite a data de início (no formato dd/MM/yyyy): ");
		String dataInicioStr = scanner.nextLine();
		Date dataInicio = null;
		try {
			dataInicio = new SimpleDateFormat("dd/MM/yyyy").parse(dataInicioStr);
		} catch (ParseException e) {
			System.out.println("Formato de data inválido.");
			return;
		}

		System.out.print("Digite a data de término (no formato dd/MM/yyyy): ");
		String dataFimStr = scanner.nextLine();
		Date dataFim = null;
		try {
			dataFim = new SimpleDateFormat("dd/MM/yyyy").parse(dataFimStr);
		} catch (ParseException e) {
			System.out.println("Formato de data inválido.");
			return;
		}

		List<Ata> atasNoPeriodo = consultarAtasPorPeriodo(dataInicio, dataFim);

		if (atasNoPeriodo.isEmpty()) {
			System.out.println("Não há atas no período especificado.");
			return;
		}

		System.out.println("Atas no período de " + dataInicio + " a " + dataFim + ":");
		for (Ata ata : atasNoPeriodo) {
			System.out.println("- " + ata.getTitulo() + " em " + ata.getDataEmissao());
		}
	}

	public void consultarAtasEscolhidaPorPalavraChave(Scanner scanner) {
		System.out.println("~~~~~~Consultar Atas por Palavra-Chave~~~~~~");

		System.out.print("Digite a palavra-chave: ");
		String palavraChave = scanner.nextLine();

		List<Ata> atasComPalavraChave = consultarAtasPorPalavraChave(palavraChave);

		if (atasComPalavraChave.isEmpty()) {
			System.out.println("Não há atas com a palavra-chave especificada.");
			return;
		}

		System.out.println("Atas com a palavra-chave '" + palavraChave + "':");
		for (Ata ata : atasComPalavraChave) {
			System.out.println("- " + ata.getTitulo() + " em " + ata.getDataEmissao());
		}
	}

	public List<Ata> consultarAtasPorPeriodo(Date dataInicio, Date dataFim) {
		List<Ata> atasNoPeriodo = new ArrayList<>();

		for (Ata ata : atas) {
			Date dataEmissao = ata.getDataEmissao();

			if (dataEmissao.after(dataInicio) && dataEmissao.before(dataFim)) {
				atasNoPeriodo.add(ata);
			}
		}

		return atasNoPeriodo;
	}

	public List<Ata> consultarAtasPorPalavraChave(String palavraChave) {
		List<Ata> atasComPalavraChave = new ArrayList<>();

		for (Ata ata : atas) {
			List<String> palavrasChaveAta = ata.getPalavrasChave();

			if (palavrasChaveAta.contains(palavraChave)) {
				atasComPalavraChave.add(ata);
			}
		}

		return atasComPalavraChave;
	}

}
