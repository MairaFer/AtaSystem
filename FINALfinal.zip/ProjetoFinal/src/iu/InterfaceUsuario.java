package iu;

import modelo.Ata;
import servico.SistemaAtas;
import servico.ArquivoBinario;
import servico.Login;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class InterfaceUsuario {
	private SistemaAtas sistemaAtas;
	private Scanner scanner;
	private boolean isAdmin;
	private Login login;
	private static final String BIN_FILE_PATH = "atas.bin";

	public InterfaceUsuario() {
		this.sistemaAtas = new SistemaAtas(new ArrayList<>(), new ArquivoBinario());
		this.scanner = new Scanner(System.in);
		this.isAdmin = false;
		this.login = new Login();

	}

	public SistemaAtas getSistemaAtas() {
		return this.sistemaAtas;
	}

	public void realizarLogin() {
		boolean loginSucesso = login.realizarLogin();
		if (loginSucesso) {
			isAdmin = true;
			System.out.println("Menu de Administrador disponível.");
		} else {
			System.out.println("Acesso ao Menu de Funcionário disponível.");
		}
	}

	public static void main(String[] args) {
		InterfaceUsuario interfaceUsuario = new InterfaceUsuario();
		List<Ata> atas = interfaceUsuario.carregarAtasDoArquivo();
		interfaceUsuario.getSistemaAtas().setAtas(atas);

		interfaceUsuario.iniciar();
	}

	private List<Ata> carregarAtasDoArquivo() {
		ArquivoBinario arquivoBinario = new ArquivoBinario();
		List<Ata> atas = (List<Ata>) arquivoBinario.carregarDeArquivo(BIN_FILE_PATH);
		if (atas == null) {
			System.out.println("Não foi possível carregar as atas do arquivo binário. Criando nova lista.");
			atas = new ArrayList<>();
		}
		return atas;
	}

	public void iniciar() {
		realizarLogin();

		while (true) {
			if (isAdmin) {
				exibirMenuAdministrador();
				int escolhaAdmin = scanner.nextInt();
				scanner.nextLine();

				switch (escolhaAdmin) {
				case 1:
					criarNovaAta();
					break;
				case 2:
					consultarAtas();
					break;
				case 3:
					realizarSugestaoAlteracao();
					break;
				case 4:
					mudarEstadoAta();
					break;
				case 5:
					excluirAta();
					break;
				case 6:
					gerarRelatorioSetor();
					break;
				case 7:
					gerarRelatorioFuncionario();
					break;
				case 8:
					gerarRelatorioDuracaoReunioes();
					break;
				case 9:
					consultarAtasPorPeriodo();
					break;
				case 10:
					consultarAtasPorPalavraChave();
					break;
				case 0:
					System.out.println("Saindo do sistema.");
					scanner.close();
					System.exit(0);
				default:
					System.out.println("Opção inválida. Tente novamente.");
				}
			} else {
				exibirMenuFuncionario();
				int escolhaFuncionario = scanner.nextInt();
				scanner.nextLine();

				switch (escolhaFuncionario) {
				case 1:
					criarNovaAta();
					break;
				case 2:
					consultarAtas();
					break;
				case 3:
					realizarSugestaoAlteracao();
					break;
				case 4:
					mudarEstadoAta();
					break;
				case 5:
					excluirAta();
					break;
				case 0:
					System.out.println("Saindo do sistema.");
					scanner.close();
					System.exit(0);

				default:
					System.out.println("Opção inválida. Tente novamente.");
				}
			}
		}
	}

	private void criarNovaAta() {
		sistemaAtas.criarNovaAta(scanner);
	}

	private void consultarAtas() {
		sistemaAtas.consultarAtas(scanner);
	}

	private void realizarSugestaoAlteracao() {
		sistemaAtas.realizarSugestaoAlteracao(scanner);
	}

	private void mudarEstadoAta() {
		sistemaAtas.mudarEstadoAta(scanner);
	}

	private void excluirAta() {
		sistemaAtas.excluirAtaSelecionada(scanner);
	}

	private void gerarRelatorioSetor() {
		sistemaAtas.gerarRelatorioSetor();
	}

	private void gerarRelatorioFuncionario() {
		sistemaAtas.gerarRelatorioFuncionario();
	}

	private void gerarRelatorioDuracaoReunioes() {
		sistemaAtas.gerarRelatorioDuracaoReunioes();
	}

	private void consultarAtasPorPeriodo() {
		sistemaAtas.consultarAtasEscolhidaPorPeriodo(scanner);
	}

	private void consultarAtasPorPalavraChave() {
		sistemaAtas.consultarAtasEscolhidaPorPalavraChave(scanner);
	}

	private void exibirMenuAdministrador() {
		System.out.println("~~~~~~~~~~~~~~Menu do Administrador~~~~~~~~~~~~~~");
		System.out.println("1] Criar Nova Ata");
		System.out.println("2] Consultar Atas");
		System.out.println("3] Realizar Sugestão de Alteração (para revisores)");
		System.out.println("4] Mudar Estado da Ata");
		System.out.println("5] Excluir Ata");
		System.out.println("6] Gerar Relatório por Setor");
		System.out.println("7] Gerar Relatório por Funcionário");
		System.out.println("8] Gerar Relatório de Duração das Reuniões");
		System.out.println("9] Consultar Atas por Período");
		System.out.println("10] Consultar Atas por Palavra-Chave");
		System.out.println("0] Sair");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.print("Escolha uma opção: ");
	}

	private void exibirMenuFuncionario() {
		System.out.println("~~~~~~~~~~~~~~~~Menu do Funcionário~~~~~~~~~~~~~~~");
		System.out.println("1]Criar Nova Ata");
		System.out.println("2] Consultar Atas");
		System.out.println("3] Realizar Sugestão de Alteração (para revisores)");
		System.out.println("4] Mudar Estado da Ata");
		System.out.println("5] Excluir Ata");
		System.out.println("0] Sair");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Escolha uma opção: ");

	}

}
