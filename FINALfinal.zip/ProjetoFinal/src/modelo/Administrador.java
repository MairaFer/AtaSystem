package modelo;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.List;

public class Administrador extends Funcionario {
	private List<Ata> listaDeAtas;

	public Administrador(String nome, String email, String cargo, Setor setor) {
		super(nome, email, cargo, setor);
		this.listaDeAtas = new ArrayList<>();
	}

	public void emitirRelatorios(Date periodoInicial, Date periodoFinal, String meioSaida) {
		calcularEstatisticasPorSetor();
		calcularEstatisticasPorFuncionario();
		calcularEstatisticasDeDuracaoDasReunioes();

		exibirResultados(meioSaida);
	}

	private void calcularEstatisticasPorSetor() {
		Map<Setor, Integer> quantidadePorSetor = new HashMap<>();

		int totalAtas = 0;

		for (Ata ata : listaDeAtas) {
			Setor setorDaAta = ata.getSetor();

			quantidadePorSetor.put(setorDaAta, quantidadePorSetor.getOrDefault(setorDaAta, 0) + 1);

			totalAtas++;
		}

		exibirResultadosPorSetor(quantidadePorSetor, totalAtas);
	}

	private void calcularEstatisticasPorFuncionario() {
		// Mapa para armazenar a quantidade de atas por funcionário
		Map<Funcionario, Integer> quantidadePorFuncionario = new HashMap<>();

		int totalAtas = 0;

		for (Ata ata : listaDeAtas) {
			// Obter o emissor da ata
			Funcionario emissorDaAta = ata.getEmissor();

			// Atualizar a contagem por funcionário
			quantidadePorFuncionario.put(emissorDaAta, quantidadePorFuncionario.getOrDefault(emissorDaAta, 0) + 1);

			// Incrementar a contagem total
			totalAtas++;
		}

		// Exibir os resultados
		exibirResultadosPorFuncionario(quantidadePorFuncionario, totalAtas);
	}

	private void calcularEstatisticasDeDuracaoDasReunioes() {
		// Lista para armazenar a duração de cada reunião em minutos
		List<Long> duracaoDasReunioesEmMinutos = new ArrayList<>();

		// Percorrer a lista de atas
		for (Ata ata : listaDeAtas) {
			// Verificar se a ata está no período especificado
			if (ata.getDataEmissao().after(periodoInicial) && ata.getDataEmissao().before(periodoFinal)) {
				// Calcular a duração da reunião em minutos
				long duracaoEmMinutos = calcularDuracaoEmMinutos(ata.getDataInicio(), ata.getDataTermino());

				// Adicionar a duração à lista
				duracaoDasReunioesEmMinutos.add(duracaoEmMinutos);
			}
		}

		// Exibir os resultados
		exibirResultadosDeDuracaoDasReunioes(duracaoDasReunioesEmMinutos);
	}

	private long calcularDuracaoEmMinutos(Date dataInicio, Date dataTermino) {
		long diferencaEmMilissegundos = dataTermino.getTime() - dataInicio.getTime();
		return TimeUnit.MILLISECONDS.toMinutes(diferencaEmMilissegundos);
	}

	private void exibirResultadosPorSetor(Map<Setor, Integer> quantidadePorSetor, int totalAtas) {
		// Exibir cabeçalho
		System.out.println("Quantidade de atas emitidas por setor:");

		// Percorrer o mapa e exibir resultados
		for (Map.Entry<Setor, Integer> entry : quantidadePorSetor.entrySet()) {
			Setor setor = entry.getKey();
			int quantidade = entry.getValue();

			// Calcular percentual
			double percentual = (double) quantidade / totalAtas * 100;

			// Exibir resultado
			System.out.printf("- Setor %s: %d atas (%.2f%% do total)\n", setor.getNome(), quantidade, percentual);
		}
	}

	private void exibirResultadosPorFuncionario(Map<Funcionario, Integer> quantidadePorFuncionario, int totalAtas) {
		// Exibir cabeçalho
		System.out.println("Quantidade de atas emitidas por funcionário:");

		// Percorrer o mapa e exibir resultados
		for (Map.Entry<Funcionario, Integer> entry : quantidadePorFuncionario.entrySet()) {
			Funcionario funcionario = entry.getKey();
			int quantidade = entry.getValue();

			// Calcular percentual
			double percentual = (double) quantidade / totalAtas * 100;

			// Exibir resultado
			System.out.printf("- Funcionário %s: %d atas (%.2f%% do total)\n", funcionario.getNome(), quantidade,
					percentual);
		}
	}

	private void exibirResultadosDeDuracaoDasReunioes(List<Long> duracaoDasReunioesEmMinutos) {
		
		System.out.println("Estatísticas de duração das reuniões:");

		// Verificar se há reuniões no período
		if (duracaoDasReunioesEmMinutos.isEmpty()) {
			System.out.println("Não há reuniões no período especificado.");
			return;
		}

		// Calcular média, máximo e mínimo
		long media = calcularMedia(duracaoDasReunioesEmMinutos);
		long maximo = Collections.max(duracaoDasReunioesEmMinutos);
		long minimo = Collections.min(duracaoDasReunioesEmMinutos);

		// Exibir resultados
		System.out.println("Média de duração: " + media + " minutos");
		System.out.println("Máximo de duração: " + maximo + " minutos");
		System.out.println("Mínimo de duração: " + minimo + " minutos");
	}

	private long calcularMedia(List<Long> numeros) {
		long soma = 0;
		for (Long numero : numeros) {
			soma += numero;
		}
		return soma / numeros.size();
	}

	private void exibirResultados(String meioSaida) {
		if (meioSaida.equalsIgnoreCase("tela")) {
			// Exibir resultados na tela
			exibirResultadosPorSetor(quantidadePorSetor, totalAtas);
			exibirResultadosPorFuncionario(quantidadePorFuncionario, totalAtas);
			exibirResultadosDeDuracaoDasReunioes(duracaoDasReunioesEmMinutos);
		} else if (meioSaida.equalsIgnoreCase("arquivo")) {
			// Salvar resultados em um arquivo de texto
			salvarResultadosEmArquivo(quantidadePorSetor, quantidadePorFuncionario, duracaoDasReunioesEmMinutos);
		} else {
			System.out.println("Meio de saída não reconhecido.");
		}
	}

	private void salvarResultadosEmArquivo(Map<Setor, Integer> quantidadePorSetor,
            Map<Funcionario, Integer> quantidadePorFuncionario, List<Long> duracaoDasReunioesEmMinutos) {
        // Nome do arquivo
        String nomeArquivo = "resultados.txt";

        try (PrintWriter writer = new PrintWriter(new FileWriter(nomeArquivo))) {
            // Escrever resultados por setor
            writer.println("Quantidade de atas emitidas por setor:");
            for (Map.Entry<Setor, Integer> entry : quantidadePorSetor.entrySet()) {
                Setor setor = entry.getKey();
                int quantidade = entry.getValue();
                double percentual = (double) quantidade / totalAtas * 100;
                writer.printf("- Setor %s: %d atas (%.2f%% do total)\n", setor.getNome(), quantidade, percentual);
            }
            writer.println(); // Adicionar linha em branco entre seções

            // Escrever resultados por funcionário
            writer.println("Quantidade de atas emitidas por funcionário:");
            for (Map.Entry<Funcionario, Integer> entry : quantidadePorFuncionario.entrySet()) {
                Funcionario funcionario = entry.getKey();
                int quantidade = entry.getValue();
                double percentual = (double) quantidade / totalAtas * 100;
                writer.printf("- Funcionário %s: %d atas (%.2f%% do total)\n", funcionario.getNome(), quantidade, percentual);
            }
            writer.println(); // Adicionar linha em branco entre seções

            // Escrever estatísticas de duração das reuniões
            writer.println("Estatísticas de duração das reuniões:");
            if (duracaoDasReunioesEmMinutos.isEmpty()) {
                writer.println("Não há reuniões no período especificado.");
            } else {
                long media = calcularMedia(duracaoDasReunioesEmMinutos);
                long maximo = Collections.max(duracaoDasReunioesEmMinutos);
                long minimo = Collections.min(duracaoDasReunioesEmMinutos);
                writer.println("Média de duração: " + media + " minutos");
                writer.println("Máximo de duração: " + maximo + " minutos");
                writer.println("Mínimo de duração: " + minimo + " minutos");
            }

            System.out.println("Resultados salvos em " + nomeArquivo);
        } catch (IOException e) {
            System.err.println("Erro ao salvar resultados em arquivo: " + e.getMessage());
        }
    }


	/*public void consultarAta(String titulo) {
		// Percorrer a lista de atas
		for (Ata ata : listaDeAtas) {
			// Verificar se o título da ata corresponde ao título fornecido
			if (ata.getTitulo().equalsIgnoreCase(titulo)) {
				// Exibir ou realizar outras ações com a ata encontrada
				System.out.println("Ata encontrada: " + ata.getTitulo());
				return; // Se encontrou, não é necessário continuar a busca
			}
		}

		// Se chegou aqui, a ata não foi encontrada
		System.out.println("Ata não encontrada com o título: " + titulo);
	}

	public void mudarEstadoAta(Ata ata, String novoEstado) {
		// Verificar se a ata está na lista
		if (listaDeAtas.contains(ata)) {
			// Mudar o estado da ata
			ata.mudarEstado(novoEstado);
		} else {
			System.out.println("Ata não encontrada na lista.");
		}
	}

	public void mostrarAta(Ata ata) {
		// Verificar se a ata está na lista
		if (listaDeAtas.contains(ata)) {
			// Exibir os detalhes da ata
			System.out.println("Detalhes da Ata:\n" + ata.toString());
		} else {
			System.out.println("Ata não encontrada na lista.");
		}
	}

	public void excluirAta(Ata ata) {
		if (listaDeAtas.contains(ata)) {
			// Remover a ata da lista
			listaDeAtas.remove(ata);
			System.out.println("Ata excluída com sucesso.");
		} else {
			System.out.println("Ata não encontrada na lista.");
		}
	}
}
