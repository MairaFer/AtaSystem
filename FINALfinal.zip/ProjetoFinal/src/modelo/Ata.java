package modelo;

import java.util.Date;
import java.util.List;
import java.io.Serializable;

public class Ata implements Serializable{

	private String titulo;
	private Date dataEmissao;
	private Funcionario emissor;
	private List<Participante> participantes;
	private Setor setor;
	private String pauta;
	private String descricao;
	private List<String> palavrasChave;
	private String estado;
	private String visibilidade;
	private Date horaInicio;
	private Date horaFim;

	public Ata(String titulo, Date dataEmissao, Funcionario emissor, List<Participante> participantes, Setor setor,
			String pauta, String descricao, List<String> palavrasChave, String estado, String visibilidade,
			Date horaInicio, Date horaFim) {
		this.titulo = titulo;
		this.dataEmissao = dataEmissao;
		this.emissor = emissor;
		this.participantes = participantes;
		this.setor = setor;
		this.pauta = pauta;
		this.descricao = descricao;
		this.palavrasChave = palavrasChave;
		this.estado = estado;
		this.visibilidade = visibilidade;
		this.horaInicio = horaInicio;
		this.horaFim = horaFim;
	}

	public String getTitulo() {
		return titulo;
	}

	public Date getDataEmissao() {
		return dataEmissao;
	}

	public Funcionario getEmissor() {
		return emissor;
	}

	public List<Participante> getParticipantes() {
		return participantes;
	}

	public Setor getSetor() {
		return setor;
	}

	public String getPauta() {
		return pauta;
	}

	public String getDescricao() {
		return descricao;
	}

	public List<String> getPalavrasChave() {
		return palavrasChave;
	}

	public String getEstado() {
		return estado;
	}

	public String getVisibilidade() {
		return visibilidade;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setDataEmissao(Date dataEmissao) {
		this.dataEmissao = dataEmissao;
	}

	public void setEmissor(Funcionario emissor) {
		this.emissor = emissor;
	}

	public void setParticipantes(List<Participante> participantes) {
		this.participantes = participantes;
	}

	public void setSetor(Setor setor) {
		this.setor = setor;
	}

	public void setPauta(String pauta) {
		this.pauta = pauta;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public void setPalavrasChave(List<String> palavrasChave) {
		this.palavrasChave = palavrasChave;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public void setVisibilidade(String visibilidade) {
		this.visibilidade = visibilidade;
	}

    public Date getHoraInicio() {
        return horaInicio;
    }

    public Date getHoraFim() {
        return horaFim;
    }

    public void setHoraInicio(Date horaInicio) {
        this.horaInicio = horaInicio;
    }

    public void setHoraFim(Date horaFim) {
        this.horaFim = horaFim;
    }

	public String toString() {
		StringBuilder details = new StringBuilder();
		details.append("Título: ").append(titulo).append("\n");
		details.append("Data de Emissão: ").append(dataEmissao).append("\n");
		details.append("Emissor: ").append(emissor).append("\n");
		details.append("Participantes: ").append(participantes).append("\n");
		details.append("Setor: ").append(setor).append("\n");
		details.append("Pauta: ").append(pauta).append("\n");
		details.append("Descrição: ").append(descricao).append("\n");
		details.append("Palavras-Chave: ").append(palavrasChave).append("\n");
		details.append("Estado: ").append(estado).append("\n");
		details.append("Visibilidade: ").append(visibilidade).append("\n");
		return details.toString();
	}

}
