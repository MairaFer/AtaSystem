package modelo;
import java.io.Serializable;

public class Setor implements Serializable {
	private String nome;

	public Setor(String nome) {
		if (!nome.equalsIgnoreCase("adm") && !nome.equalsIgnoreCase("ti") && !nome.equalsIgnoreCase("rh")) {
			throw new IllegalArgumentException("Setor inválido. Escolha entre 'adm', 'ti' e 'rh'.");
		}

		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
        if (!nome.equalsIgnoreCase("adm") && !nome.equalsIgnoreCase("ti") && !nome.equalsIgnoreCase("rh")) {
            throw new IllegalArgumentException("Setor inválido. Escolha entre 'adm', 'ti' e 'rh'.");
        }

        this.nome = nome;
    }

}
