package modelo;

public class ParticipanteExterno extends Participante {
	private String empresa;

	public ParticipanteExterno(String nome, String email, String empresa) {
		super(nome, email);
		this.empresa = empresa;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String toString() {
		return "ParticipanteExterno{" + "nome='" + getNome() + '\'' + ", email='" + getEmail() + '\'' + ", empresa='"
				+ empresa + '\'' + '}';
	}
}
