package modelo;
import java.io.Serializable;

public class Participante implements Serializable {
	
    private String nome;
    private String email;

    public Participante(String nome, String email) {
        this.nome = nome;
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public void SugerirAlteracao(Ata ata, String descricao) {
        if (ata != null) {
            if (descricao != null) {
                ata.setDescricao(descricao);
            }
 
            System.out.println("Sugestão de alteração realizada com sucesso!");
        } else {
            System.out.println("Não foi possível realizar a sugestão. Ata não encontrada.");
        }
    }

}
