package utilitario;

import modelo.Ata;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.Duration;
import java.time.Instant;

public class Relatorio {

	public Relatorio() {
	}

	public void gerarRelatorioSetor(List<Ata> atas) {
		if (atas.isEmpty()) {
			System.out.println("Não há atas para gerar o relatório de setores.");
			return;
		}
		Map<String, Integer> contagemPorSetor = new HashMap<>();

		for (Ata ata : atas) {
			String nomeSetor = ata.getSetor().getNome();

			contagemPorSetor.put(nomeSetor, contagemPorSetor.getOrDefault(nomeSetor, 0) + 1);
		}

		System.out.println("Relatório de Atas por Setor:");
		for (Map.Entry<String, Integer> entry : contagemPorSetor.entrySet()) {
			String nomeSetor = entry.getKey();
			int quantidadeAtas = entry.getValue();

			System.out.println(nomeSetor + ": " + quantidadeAtas + " atas");
		}
	}

	public void gerarRelatorioFuncionario(List<Ata> atas) {
		if (atas.isEmpty()) {
			System.out.println("Não há atas para gerar o relatório de funcionários.");
			return;
		}

		Map<String, Integer> contagemPorFuncionario = new HashMap<>();

		for (Ata ata : atas) {
			String nomeFuncionario = ata.getEmissor().getNome();

			contagemPorFuncionario.put(nomeFuncionario, contagemPorFuncionario.getOrDefault(nomeFuncionario, 0) + 1);
		}

		System.out.println("Relatório de Atas por Funcionário:");
		for (Map.Entry<String, Integer> entry : contagemPorFuncionario.entrySet()) {
			String nomeFuncionario = entry.getKey();
			int quantidadeAtas = entry.getValue();

			System.out.println(nomeFuncionario + ": " + quantidadeAtas + " atas");
		}
	}

	 public void gerarRelatorioDuracaoReunioes(List<Ata> atas) {
	        if (atas.isEmpty()) {
	            System.out.println("Não há atas para gerar o relatório de duração de reuniões.");
	            return;
	        }

	        long duracaoTotal = 0;
	        int numeroReunioes = 0;

	        for (Ata ata : atas) {
	            if (ata.getHoraInicio() != null && ata.getHoraFim() != null) {
	                Instant inicio = ata.getHoraInicio().toInstant();
	                Instant fim = ata.getHoraFim().toInstant();
	                
	                Duration duracaoReuniao = Duration.between(inicio, fim);
	                duracaoTotal += duracaoReuniao.toMinutes();
	                numeroReunioes++;
	            }
	        }

	        if (numeroReunioes > 0) {
	            long duracaoMedia = duracaoTotal / numeroReunioes;
	            long duracaoMinima = 0;
	            long duracaoMaxima = 0;  

	            System.out.println("Relatório de Duração das Reuniões:");
	            System.out.println("Duração Média: " + duracaoMedia + " minutos");

	            if (duracaoMinima > 0) {
	                System.out.println("Duração Mínima: " + duracaoMinima + " minutos");
	            }

	            if (duracaoMaxima > 0) {
	                System.out.println("Duração Máxima: " + duracaoMaxima + " minutos");
	            }
	        } else {
	            System.out.println("Não há reuniões válidas para calcular a duração média.");
	        }
	    }

}
